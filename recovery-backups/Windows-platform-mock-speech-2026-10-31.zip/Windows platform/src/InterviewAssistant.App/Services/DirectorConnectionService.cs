using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace InterviewAssistant.Services;

public sealed class DirectorPacket
{
    public string Kind { get; set; } = "hello";
    public string? QuestionID { get; set; }
    public string? Text { get; set; }
    public string? Mode { get; set; }
    public bool? HostBoardOpen { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class DirectorConnectionService : IAsyncDisposable
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    private TcpClient? _client;
    private StreamWriter? _writer;
    private CancellationTokenSource? _connectionCancellation;

    public event Action<DirectorPacket>? PacketReceived;
    public event Action<string>? StatusChanged;
    public bool IsConnected => _client?.Connected == true;

    public async Task ConnectAsync(string host, int port = 9999, CancellationToken cancellationToken = default)
    {
        await DisconnectAsync();
        var cleanHost = host.Trim().Trim(',', '，', ';', '；');
        if (cleanHost.Length == 0) throw new InvalidOperationException("Enter the Host IP address.");

        StatusChanged?.Invoke($"Connecting to {cleanHost}…");
        var cancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        _connectionCancellation = cancellation;
        var client = new TcpClient();
        _client = client;
        await client.ConnectAsync(cleanHost, port, cancellation.Token);
        var stream = client.GetStream();
        _writer = new StreamWriter(stream) { AutoFlush = true, NewLine = "\n" };
        StatusChanged?.Invoke("Connected to host");
        await SendAsync(new DirectorPacket { Kind = "hello" }, cancellation.Token);
        _ = ReadLoopAsync(new StreamReader(stream), cancellation.Token);
    }

    public async Task SendAsync(DirectorPacket packet, CancellationToken cancellationToken = default)
    {
        if (_writer is null) throw new InvalidOperationException("Connect to a Host first.");
        var line = JsonSerializer.Serialize(packet, JsonOptions);
        await _writer.WriteLineAsync(line.AsMemory(), cancellationToken);
    }

    public Task DisconnectAsync()
    {
        _connectionCancellation?.Cancel();
        _connectionCancellation?.Dispose();
        _connectionCancellation = null;
        _writer?.Dispose();
        _writer = null;
        _client?.Dispose();
        _client = null;
        StatusChanged?.Invoke("Disconnected");
        return Task.CompletedTask;
    }

    public ValueTask DisposeAsync()
    {
        _ = DisconnectAsync();
        return ValueTask.CompletedTask;
    }

    public static string GetLocalIPv4Address()
    {
        foreach (var networkInterface in NetworkInterface.GetAllNetworkInterfaces()
                     .Where(item => item.OperationalStatus == OperationalStatus.Up && item.NetworkInterfaceType != NetworkInterfaceType.Loopback))
        {
            foreach (var address in networkInterface.GetIPProperties().UnicastAddresses)
            {
                if (address.Address.AddressFamily != AddressFamily.InterNetwork) continue;
                var bytes = address.Address.GetAddressBytes();
                if (bytes[0] == 10 || (bytes[0] == 192 && bytes[1] == 168) || (bytes[0] == 172 && bytes[1] is >= 16 and <= 31))
                {
                    return address.Address.ToString();
                }
            }
        }
        return "No private IPv4 address detected";
    }

    private async Task ReadLoopAsync(StreamReader reader, CancellationToken cancellationToken)
    {
        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                var line = await reader.ReadLineAsync(cancellationToken);
                if (line is null) break;
                if (line.Length == 0) continue;
                var packet = JsonSerializer.Deserialize<DirectorPacket>(line, JsonOptions);
                if (packet is not null) PacketReceived?.Invoke(packet);
            }
            if (!cancellationToken.IsCancellationRequested) StatusChanged?.Invoke("The Host closed the connection");
        }
        catch (OperationCanceledException)
        {
        }
        catch (Exception exception)
        {
            StatusChanged?.Invoke($"Connection error: {exception.Message}");
        }
    }
}
