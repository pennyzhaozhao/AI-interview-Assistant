using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using InterviewAssistant.Infrastructure;
using InterviewAssistant.Services;
using QRCoder;
using System.IO;
using System.Windows.Media.Imaging;

namespace InterviewAssistant.ViewModels;

public sealed class DirectorViewModel : PageViewModel
{
    private readonly DirectorConnectionService _connection = new();
    private string _hostIp = "";
    private string _status = "Waiting for host connection";
    private string _draft = "";
    private RemoteQuestionViewModel? _selectedQuestion;
    private bool _hostBoardOpen;
    private string _remoteMode = "director";

    public DirectorViewModel() : base("Director Mode", "Host a prompt board or connect as a controller")
    {
        LocalIp = DirectorConnectionService.GetLocalIPv4Address();
        ControllerQrCode = CreateQrCode($"http://{LocalIp}:9999");
        ConnectCommand = new AsyncRelayCommand(ConnectAsync);
        SendCommand = new AsyncRelayCommand(SendAsync);
        ClearCommand = new RelayCommand(() => Draft = "");
        OpenHostBoardCommand = new RelayCommand(() => HostBoardRequested?.Invoke());
        _connection.StatusChanged += status => Application.Current.Dispatcher.Invoke(() => Status = status);
        _connection.PacketReceived += packet => Application.Current.Dispatcher.Invoke(() => Receive(packet));
    }

    public string LocalIp { get; }
    public BitmapImage ControllerQrCode { get; }
    public ObservableCollection<RemoteQuestionViewModel> Questions { get; } = [];
    public ICommand ConnectCommand { get; }
    public ICommand SendCommand { get; }
    public ICommand ClearCommand { get; }
    public ICommand OpenHostBoardCommand { get; }
    public event Action? HostBoardRequested;

    public string HostIp
    {
        get => _hostIp;
        set => SetProperty(ref _hostIp, value);
    }

    public string Status
    {
        get => _status;
        private set => SetProperty(ref _status, value);
    }

    public string Draft
    {
        get => _draft;
        set => SetProperty(ref _draft, value);
    }

    public RemoteQuestionViewModel? SelectedQuestion
    {
        get => _selectedQuestion;
        set => SetProperty(ref _selectedQuestion, value);
    }

    public bool HostBoardOpen
    {
        get => _hostBoardOpen;
        private set => SetProperty(ref _hostBoardOpen, value);
    }

    public string RemoteMode
    {
        get => _remoteMode;
        private set => SetProperty(ref _remoteMode, value);
    }

    private async Task ConnectAsync()
    {
        try
        {
            await _connection.ConnectAsync(HostIp);
        }
        catch (Exception exception)
        {
            Status = exception.Message;
        }
    }

    private async Task SendAsync()
    {
        var text = Draft.Trim();
        if (text.Length == 0) return;
        if (!_connection.IsConnected)
        {
            Status = "Connect to a Host before sending.";
            return;
        }
        if (!HostBoardOpen)
        {
            Status = "The Host prompt board is closed.";
            return;
        }
        if (string.Equals(RemoteMode, "ai", StringComparison.OrdinalIgnoreCase))
        {
            Status = "The Host is currently in AI mode.";
            return;
        }

        try
        {
            await _connection.SendAsync(new DirectorPacket
            {
                Kind = "answer",
                QuestionID = SelectedQuestion?.Id,
                Text = text
            });
            SelectedQuestion?.Answers.Add(text);
            Draft = "";
            Status = "Answer sent";
        }
        catch (Exception exception)
        {
            Status = exception.Message;
        }
    }

    private void Receive(DirectorPacket packet)
    {
        if (packet.HostBoardOpen is { } isOpen) HostBoardOpen = isOpen;
        if (!string.IsNullOrWhiteSpace(packet.Mode)) RemoteMode = packet.Mode;
        if ((packet.Kind != "question" && packet.Kind != "snapshot") || string.IsNullOrWhiteSpace(packet.QuestionID) || packet.Text is null) return;

        var question = Questions.FirstOrDefault(item => item.Id == packet.QuestionID);
        if (question is null)
        {
            question = new RemoteQuestionViewModel(packet.QuestionID, packet.Text);
            Questions.Add(question);
        }
        else
        {
            question.Text = packet.Text;
        }
        SelectedQuestion = question;
    }

    private static BitmapImage CreateQrCode(string value)
    {
        using var generator = new QRCodeGenerator();
        using var data = generator.CreateQrCode(value, QRCodeGenerator.ECCLevel.M);
        var bytes = new PngByteQRCode(data).GetGraphic(8);
        using var stream = new MemoryStream(bytes);
        var image = new BitmapImage();
        image.BeginInit();
        image.CacheOption = BitmapCacheOption.OnLoad;
        image.StreamSource = stream;
        image.EndInit();
        image.Freeze();
        return image;
    }
}

public sealed class RemoteQuestionViewModel(string id, string text) : ObservableObject
{
    private string _text = text;
    public string Id { get; } = id;
    public ObservableCollection<string> Answers { get; } = [];
    public string Text
    {
        get => _text;
        set => SetProperty(ref _text, value);
    }
}
