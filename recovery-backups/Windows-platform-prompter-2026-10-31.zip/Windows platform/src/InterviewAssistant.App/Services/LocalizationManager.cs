using System.ComponentModel;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Markup;

namespace InterviewAssistant.Services;

public sealed class LocalizationManager : INotifyPropertyChanged
{
    private static readonly IReadOnlyDictionary<string, string> EnglishAliases = new Dictionary<string, string>(StringComparer.Ordinal)
    {
        ["HomeRoleDescription"] = "Shape the interview around the exact opportunity.",
        ["HomeCompanyDescription"] = "Record the website, business, compensation structure, and company understanding you may be asked about in interviews.",
        ["KnowledgeEditDescription"] = "Edit metadata, import sources, and decide whether this asset is available to interviews.",
        ["StorageDescription"] = "Interview history, knowledge bases, and screenshots are stored together in this folder.",
        ["AboutDescription"] = "Version, support, and app information",
        ["EditSourceDescription"] = "Edit the source title and full text. Changes are saved locally.",
        ["ScreenshotModeDescription"] = "Choose whether screenshots use a preset region for silent capture during interviews.",
        ["PresetRegionDescription"] = "Set the region before the interview, then capture silently without stealing focus.",
        ["ManualRegionDescription"] = "Select an area manually each time. This can briefly move focus away from the interview.",
        ["RegionSetupHint"] = "Set the region before the interview starts so capturing does not affect the interview window."
    };

    private static readonly IReadOnlyDictionary<string, string> Chinese = new Dictionary<string, string>(StringComparer.Ordinal)
    {
        ["Interview"] = "面试", ["Director Mode"] = "导演模式", ["Knowledge Base"] = "知识库", ["History"] = "历史", ["Settings"] = "设置",
        ["Interview AI"] = "Interview AI", ["Practice smarter. Ace your next interview."] = "更聪明地练习，拿下下一场面试。",
        ["Start Interview"] = "开始面试", ["Mock Interview"] = "模拟面试", ["Choose Knowledge"] = "选择知识库",
        ["Microphone"] = "麦克风", ["System Audio"] = "扬声器", ["Muted"] = "静音", ["Choose code language"] = "选择代码语言",
        ["Role"] = "角色", ["Target role"] = "目标岗位", ["Job description"] = "职位描述", ["Company Introduction"] = "公司介绍",
        ["Company Name"] = "公司名称", ["Company Website"] = "公司官网", ["Company Notes"] = "公司备注", ["Parse Website"] = "解析网站",
        ["Add a target role before starting."] = "请先填写目标岗位。", ["Mock interview setup is ready. The interview room is the next module."] = "模拟面试资料已就绪，下一步将进入面试房间。",
        ["Enter a valid company website first."] = "请先输入有效的公司网址。", ["Reading company website…"] = "正在读取公司网站…",
        ["Company website content was added to your notes."] = "公司网站内容已添加到备注。", ["Website could not be read: {0}"] = "无法读取网站：{0}",
        ["Interview workspace for {0} is ready."] = "{0} 的面试工作区已准备好。", ["Interview workspace is ready."] = "面试工作区已准备好。",
        ["HomeRoleDescription"] = "围绕具体岗位定制本次面试。",
        ["HomeCompanyDescription"] = "记录官网、业务、薪资架构和面试中可能被问到的公司理解。",
        ["Manage reusable context as enabled assets for interview sessions."] = "管理可复用的面试上下文资料。",
        ["Search knowledge"] = "搜索知识库", ["Select"] = "选择", ["Cancel"] = "取消", ["Select All"] = "全选", ["Delete Selected"] = "删除所选",
        ["New Asset"] = "新建资料", ["Enabled"] = "开启", ["Off"] = "关闭", ["No knowledge bases yet."] = "还没有知识库。",
        ["Select or create a knowledge base to edit its details."] = "选择或新建知识库以编辑详情。",
        ["Enabled for interviews"] = "用于面试", ["AI will prioritize this asset when answering."] = "AI 回答时会优先参考这份资料。",
        ["Title"] = "标题", ["Description"] = "描述", ["Import source"] = "导入来源", ["Import"] = "导入", ["Upload File"] = "上传文件",
        ["Sources"] = "来源", ["Add Main Content"] = "添加主要内容", ["Main Content"] = "主要内容", ["Edit Source"] = "编辑来源",
        ["Source title"] = "来源标题", ["Content"] = "内容", ["Save"] = "保存", ["Saving…"] = "正在保存…", ["Saved"] = "已保存",
        ["EditSourceDescription"] = "编辑来源标题和完整文字，修改将保存在本机。",
        ["KnowledgeEditDescription"] = "编辑元数据、导入来源，并决定这份资料是否用于面试。",
        ["Choose which materials AI can use during interviews."] = "选择面试期间 AI 可以使用的材料。",
        ["Review formal and mock interview sessions stored on this device."] = "查看过往面试对话和结果。",
        ["History Type"] = "历史类型", ["Formal Interview"] = "正式面试", ["Search history"] = "搜索历史",
        ["Conversation"] = "会话", ["Select a session to inspect the interview flow."] = "选择一个会话来查看面试流程。", ["No interview history yet."] = "还没有面试历史。",
        ["Summary"] = "总结", ["Question"] = "问题", ["Answer"] = "回答", ["No summary yet"] = "暂无总结",
        ["Language"] = "语言", ["Mode"] = "模式", ["Storage Location"] = "存储位置", ["Choose folder"] = "选择文件夹", ["Open folder"] = "打开文件夹", ["Clear all data"] = "清空全部数据",
        ["Mock Interviewer Language"] = "模拟面试官语言", ["Interviewer Speech Language"] = "面试官语音语言", ["API Configure"] = "API 配置",
        ["Screenshot Hotkey"] = "截图快捷键", ["Screenshot OCR"] = "截图识别", ["Screenshot Mode"] = "截图模式", ["Set Up Voices"] = "设置声纹", ["About"] = "关于",
        ["ScreenshotModeDescription"] = "选择面试中截图是否使用预设区域静默捕获。",
        ["Preset Region Screenshot"] = "预设区域截图", ["Manual Selection Screenshot"] = "手动框选截图",
        ["PresetRegionDescription"] = "提前设置截图区域，面试中可静默截图，不影响窗口焦点。",
        ["ManualRegionDescription"] = "每次手动框选区域，可能导致面试窗口短暂失焦。",
        ["Screen capture is available"] = "屏幕截图功能可用", ["Screenshot region set"] = "截图区域已设置", ["Screenshot region not set"] = "未设置截图区域",
        ["Set Region"] = "设置区域", ["Reset"] = "重新设置", ["RegionSetupHint"] = "建议在面试开始前设置好区域，面试中直接截图，不影响面试窗口焦点。",
        ["Follow app language"] = "跟随 App 语言", ["English"] = "英文", ["APPEARANCE"] = "外观", ["DATA STORAGE"] = "数据存储",
        ["StorageDescription"] = "历史记录、知识库和截图统一保存在这个文件夹中。",
        ["Changing the location copies your existing data safely. Restart the app once to begin using the new folder."] = "更改位置时会安全复制现有数据。重启应用后开始使用新文件夹。",
        ["Hide prompter during screen sharing"] = "屏幕共享时隐藏提示板", ["Hide Interview AI from the taskbar during interviews"] = "面试期间从任务栏隐藏 Interview AI",
        ["AboutDescription"] = "版本、支持与应用信息",
        ["Host a prompt board or connect as a controller"] = "开启提示板，或作为控制端连接", ["Start"] = "开始", ["Connect"] = "连接", ["Clear"] = "清空", ["Send"] = "发送"
    };

    public static LocalizationManager Instance { get; } = new();
    public event PropertyChangedEventHandler? PropertyChanged;
    public event Action? LanguageChanged;
    public bool IsChinese { get; private set; }
    public string this[string key]
    {
        get
        {
            if (IsChinese && Chinese.TryGetValue(key, out var chinese)) return chinese;
            return EnglishAliases.TryGetValue(key, out var english) ? english : key;
        }
    }

    public static string Text(string key) => Instance[key];

    public static void Apply(string language)
    {
        var chinese = language.StartsWith("zh", StringComparison.OrdinalIgnoreCase) || language == "简体中文";
        if (Instance.IsChinese == chinese) return;
        Instance.IsChinese = chinese;
        CultureInfo.CurrentUICulture = chinese ? CultureInfo.GetCultureInfo("zh-Hans") : CultureInfo.GetCultureInfo("en");
        Instance.PropertyChanged?.Invoke(Instance, new PropertyChangedEventArgs("Item[]"));
        Instance.LanguageChanged?.Invoke();
    }
}

[MarkupExtensionReturnType(typeof(object))]
public sealed class LocExtension : MarkupExtension
{
    public string Key { get; set; } = "";

    public override object ProvideValue(IServiceProvider serviceProvider) =>
        new Binding($"[{Key}]") { Source = LocalizationManager.Instance, Mode = BindingMode.OneWay }
            .ProvideValue(serviceProvider);
}
