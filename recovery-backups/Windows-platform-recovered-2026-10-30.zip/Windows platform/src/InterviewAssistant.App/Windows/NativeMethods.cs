using System.Runtime.InteropServices;

namespace InterviewAssistant.Windows;

internal static class NativeMethods
{
    internal const int GwlExStyle = -20;
    internal const int WsExToolWindow = 0x00000080;
    internal const int WsExNoActivate = 0x08000000;
    internal const uint WdaExcludeFromCapture = 0x00000011;
    internal const int DwmwaWindowCornerPreference = 33;
    internal const int DwmwcpRound = 2;

    [DllImport("user32.dll", SetLastError = true)]
    internal static extern int GetWindowLong(nint windowHandle, int index);

    [DllImport("user32.dll", SetLastError = true)]
    internal static extern int SetWindowLong(nint windowHandle, int index, int newStyle);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static extern bool SetWindowDisplayAffinity(nint windowHandle, uint affinity);

    [DllImport("dwmapi.dll")]
    internal static extern int DwmSetWindowAttribute(nint windowHandle, int attribute, ref int attributeValue, int attributeSize);
}
