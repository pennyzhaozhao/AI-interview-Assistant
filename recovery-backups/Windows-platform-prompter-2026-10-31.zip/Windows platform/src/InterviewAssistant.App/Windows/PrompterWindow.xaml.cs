using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using InterviewAssistant.Models;
using InterviewAssistant.Services;
using InterviewAssistant.ViewModels;

namespace InterviewAssistant.Windows;

public partial class PrompterWindow : Window
{
    private const double ExpandedWidth = 600;
    private const double DefaultExpandedHeight = 240;
    private const double CompactWidth = 80;
    private const double CompactHeight = 37;
    private readonly AppDataStore _store = AppServices.Current.DataStore;
    private readonly InterviewSessionModel _session;
    private bool _isDirectorMode;
    private readonly DispatcherTimer _waveTimer;
    private nint _windowHandle;
    private int _turnIndex = -1;
    private bool _isCompact;
    private PrompterAudioMode _audioMode = PrompterAudioMode.Microphone;
    private bool _isResizing;
    private double _expandedHeight = DefaultExpandedHeight;
    private double _resizeStartScreenY;
    private double _resizeStartHeight;
    private int _waveStep;
    private string _codeLanguage = "python";

    public PrompterWindow() : this(new InterviewSessionModel { Title = "Prompter preview", Role = "Interview preview" }, false) { }

    public PrompterWindow(bool directorMode) : this(
        new InterviewSessionModel { Title = directorMode ? "Director Mode" : "Prompter preview", Role = directorMode ? "Director Mode" : "Interview preview", Kind = directorMode ? "director" : "formal" },
        directorMode) { }

    public PrompterWindow(InterviewSessionModel session) : this(session, false) { }

    private PrompterWindow(InterviewSessionModel session, bool directorMode)
    {
        _session = session;
        _isDirectorMode = directorMode || string.Equals(session.Kind, "director", StringComparison.OrdinalIgnoreCase);
        InitializeComponent();
        Loaded += PrompterWindow_Loaded;
        SizeChanged += (_, _) => PositionAtTopCenter();
        _waveTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(120) };
        _waveTimer.Tick += (_, _) => AnimateWaveform();
        _waveTimer.Start();
        KnowledgeCountText.Text = session.ActiveKnowledgeBaseIds.Count.ToString();
        ApplyPrompterMode(refreshContent: false);
        _store.Changed += StoreChanged;
        RefreshTurns(showLatest: true);
    }

    public bool CaptureExclusionApplied { get; private set; }
    public event Action? ScreenshotRequested;
    public event Action<PrompterAudioMode>? AudioInputChanged;
    public event Action<bool>? DirectorModeChanged;

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        _windowHandle = new WindowInteropHelper(this).Handle;
        var extendedStyle = NativeMethods.GetWindowLong(_windowHandle, NativeMethods.GwlExStyle);
        _ = NativeMethods.SetWindowLong(_windowHandle, NativeMethods.GwlExStyle, extendedStyle | NativeMethods.WsExToolWindow | NativeMethods.WsExNoActivate);
        ApplyCaptureExclusion();
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        _waveTimer.Stop();
        _store.Changed -= StoreChanged;
        if (_windowHandle != nint.Zero) _ = NativeMethods.SetWindowDisplayAffinity(_windowHandle, 0);
        if (_session.EndedAt is null && _session.Turns.Count > 0)
        {
            _session.EndedAt = DateTimeOffset.Now;
            _session.UpdatedAt = DateTimeOffset.Now;
            _store.ScheduleSave();
        }
        base.OnClosing(e);
    }

    public async Task SubmitQuestionAsync(string question, CancellationToken cancellationToken = default)
    {
        question = question.Trim();
        if (question.Length == 0) return;
        var turn = new ConversationTurnModel { Question = question, SpeakerLabel = "interviewer" };
        _session.Turns.Add(turn);
        _session.UpdatedAt = DateTimeOffset.Now;
        _turnIndex = _session.Turns.Count - 1;
        ShowPreparing(question);
        _store.ScheduleSave();
        try
        {
            var answer = await AppServices.Current.AI.CompleteAsync(CurrentAIConfig(), BuildSystemPrompt(), question, cancellationToken: cancellationToken);
            turn.Answer = answer;
            turn.SpeakerLabel = "assistant";
            _session.UpdatedAt = DateTimeOffset.Now;
            _store.ScheduleSave();
            Dispatcher.Invoke(() => RenderTurn(_turnIndex));
        }
        catch (OperationCanceledException)
        {
            Dispatcher.Invoke(() => ShowMessage(Localized("Answer generation was cancelled.", "回答生成已取消。"), true));
        }
        catch (Exception exception)
        {
            turn.Answer = $"AI request failed: {exception.Message}";
            _store.ScheduleSave();
            Dispatcher.Invoke(() => RenderTurn(_turnIndex));
        }
    }

    public void RefreshTurns(bool showLatest)
    {
        if (_session.Turns.Count == 0)
        {
            _turnIndex = -1;
            QuestionText.Text = _isDirectorMode
                ? Localized("Waiting for Host question...", "等待 Host 问题…")
                : Localized("Waiting for interview question...", "等待面试问题…");
            AnswerText.Text = _isDirectorMode
                ? Localized("Waiting for answer", "等待回答")
                : Localized("Waiting for AI answer...", "等待 AI 回答…");
            AnswerText.Foreground = (Brush)FindResource("IslandSecondary");
            PreparingPanel.Visibility = Visibility.Collapsed;
            AnswerScroller.Visibility = Visibility.Visible;
            UpdateNavigationButtons();
            return;
        }
        if (showLatest || _turnIndex < 0 || _turnIndex >= _session.Turns.Count) _turnIndex = _session.Turns.Count - 1;
        RenderTurn(_turnIndex);
    }

    private void PrompterWindow_Loaded(object sender, RoutedEventArgs e)
    {
        foreach (var existing in Application.Current.Windows.OfType<PrompterWindow>().Where(window => !ReferenceEquals(window, this)).ToArray())
        {
            existing.Close();
        }
        PositionAtTopCenter();
        ApplyCaptureExclusion();
        Dispatcher.BeginInvoke(DispatcherPriority.ContextIdle, new Action(ApplyCaptureExclusion));
        Opacity = 0;
        BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(240)) { EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut } });
    }

    private void ApplyCaptureExclusion()
    {
        if (_windowHandle == nint.Zero) return;
        var shouldExclude = _store.Data.Preferences.HidePrompterFromCapture;
        if (!shouldExclude)
        {
            _ = NativeMethods.SetWindowDisplayAffinity(_windowHandle, 0);
            CaptureExclusionApplied = false;
            return;
        }

        CaptureExclusionApplied = NativeMethods.SetWindowDisplayAffinity(_windowHandle, NativeMethods.WdaExcludeFromCapture)
            && NativeMethods.GetWindowDisplayAffinity(_windowHandle, out var affinity)
            && affinity == NativeMethods.WdaExcludeFromCapture;
        if (!CaptureExclusionApplied)
        {
            CaptureExclusionApplied = NativeMethods.SetWindowDisplayAffinity(_windowHandle, NativeMethods.WdaMonitor)
                && NativeMethods.GetWindowDisplayAffinity(_windowHandle, out affinity)
                && affinity == NativeMethods.WdaMonitor;
        }
    }

    private void StoreChanged()
    {
        if (Dispatcher.CheckAccess()) ApplyCaptureExclusion();
        else Dispatcher.BeginInvoke(new Action(ApplyCaptureExclusion));
    }

    private void PositionAtTopCenter()
    {
        var area = SystemParameters.WorkArea;
        Left = area.Left + Math.Max(0, (area.Width - ActualWidth) / 2);
        Top = area.Top;
    }

    private void RenderTurn(int index)
    {
        if (index < 0 || index >= _session.Turns.Count) return;
        var turn = _session.Turns[index];
        QuestionText.Text = string.IsNullOrWhiteSpace(turn.Question) ? Localized("Interview question", "面试问题") : turn.Question;
        AnswerText.Text = string.IsNullOrWhiteSpace(turn.Answer)
            ? (_isDirectorMode ? Localized("Waiting for answer", "等待回答") : Localized("Waiting for AI answer...", "等待 AI 回答…"))
            : turn.Answer;
        AnswerText.Foreground = (Brush)FindResource(string.IsNullOrWhiteSpace(turn.Answer) ? "IslandSecondary" : "IslandPrimary");
        PreparingPanel.Visibility = Visibility.Collapsed;
        AnswerScroller.Visibility = Visibility.Visible;
        AnswerScroller.ScrollToTop();
        UpdateNavigationButtons();
    }

    private void ShowPreparing(string question)
    {
        Dispatcher.Invoke(() =>
        {
            QuestionText.Text = question;
            PreparingText.Text = Localized("Preparing answer suggestion...", "正在准备回答建议…");
            AnswerScroller.Visibility = Visibility.Collapsed;
            PreparingPanel.Visibility = Visibility.Visible;
            UpdateNavigationButtons();
        });
    }

    private void ShowMessage(string message, bool isError = false)
    {
        PreparingPanel.Visibility = Visibility.Collapsed;
        AnswerScroller.Visibility = Visibility.Visible;
        AnswerText.Text = message;
        AnswerText.Foreground = isError ? Brushes.IndianRed : (Brush)FindResource("IslandSecondary");
    }

    private void UpdateNavigationButtons()
    {
        PreviousButton.IsEnabled = _turnIndex > 0;
        NextButton.IsEnabled = _turnIndex >= 0 && _turnIndex < _session.Turns.Count - 1;
    }

    private AIConfig CurrentAIConfig()
    {
        if (!Enum.TryParse<AIProvider>(_store.Data.Preferences.Provider, true, out var provider)) provider = AIProvider.DeepSeek;
        var settings = _store.GetProviderSettings(provider);
        var key = AppServices.Current.Credentials.Read(provider.ToString().ToLowerInvariant());
        return new AIConfig(provider, settings.ApiUrl, key, settings.Model);
    }

    private string BuildSystemPrompt()
    {
        var builder = new StringBuilder("You are a discreet real-time interview assistant. Give a direct, natural answer the candidate can say aloud. Prefer concise paragraphs and concrete examples.\n");
        if (!string.IsNullOrWhiteSpace(_session.Role)) builder.AppendLine($"Target role: {_session.Role}");
        if (!string.IsNullOrWhiteSpace(_session.Context)) builder.AppendLine($"Job context: {_session.Context}");
        var context = string.Join("\n\n", _store.Data.KnowledgeBases.Where(item => _session.ActiveKnowledgeBaseIds.Contains(item.Id)).SelectMany(item => item.Entries.Where(entry => entry.IsEnabled)).Select(entry => $"{entry.Title}: {entry.Content}"));
        if (context.Length > 12000) context = context[..12000];
        if (context.Length > 0) builder.AppendLine($"Candidate knowledge base:\n{context}");
        builder.AppendLine($"When code is useful, use {_codeLanguage}.");
        return builder.ToString();
    }

    private string Localized(string english, string chinese) => _store.Data.Preferences.Language.StartsWith("zh", StringComparison.OrdinalIgnoreCase) ? chinese : english;

    private void AnimateWaveform()
    {
        if (_audioMode == PrompterAudioMode.Muted) return;
        _waveStep++;
        var bars = new[] { Wave1, Wave2, Wave3, Wave4, Wave5, Wave6 };
        var heights = new[] { 5d, 10d, 16d, 8d, 13d, 6d };
        for (var index = 0; index < bars.Length; index++) bars[index].Height = Math.Max(3, heights[index] * (0.55 + 0.45 * Math.Abs(Math.Sin((_waveStep + index * 1.7) * 0.55))));
    }

    private void SetWindowSize(double width, double height)
    {
        // Resizing a transparent layered WPF window with Width/Height animations leaves
        // stale compositor frames on some Windows/VM graphics drivers. Switch the native
        // surface atomically and only fade the child content.
        BeginAnimation(WidthProperty, null);
        BeginAnimation(HeightProperty, null);
        Width = width;
        Height = height;
        UpdateLayout();
        PositionAtTopCenter();
    }

    private void MinimizeButton_Click(object sender, RoutedEventArgs e)
    {
        if (_isCompact) return;
        _isCompact = true;
        CodeLanguagePopup.IsOpen = false;
        ExpandedIsland.Visibility = Visibility.Collapsed;
        CompactIsland.Opacity = 0;
        SetWindowSize(CompactWidth, CompactHeight);
        CompactIsland.Visibility = Visibility.Visible;
        CompactIsland.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(140)));
    }

    private void RestoreButton_Click(object sender, RoutedEventArgs e)
    {
        if (!_isCompact) return;
        _isCompact = false;
        CompactIsland.Visibility = Visibility.Collapsed;
        SetWindowSize(ExpandedWidth, _expandedHeight);
        ExpandedIsland.Opacity = 0;
        ExpandedIsland.Visibility = Visibility.Visible;
        ExpandedIsland.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(170)));
    }
    private void PreviousButton_Click(object sender, RoutedEventArgs e) { if (_turnIndex > 0) RenderTurn(--_turnIndex); }
    private void NextButton_Click(object sender, RoutedEventArgs e) { if (_turnIndex < _session.Turns.Count - 1) RenderTurn(++_turnIndex); }
    private void ScreenshotButton_Click(object sender, RoutedEventArgs e)
    {
        ScreenshotRequested?.Invoke();
        if (ScreenshotRequested is null)
        {
            ShowMessage(Localized("Screenshot recognition will be connected in the input pipeline next.", "截图识别将在下一步接入输入流程。"));
        }
    }

    private void AudioButton_Click(object sender, RoutedEventArgs e)
    {
        SetAudioMode(_audioMode switch
        {
            PrompterAudioMode.Microphone => PrompterAudioMode.SystemAudio,
            PrompterAudioMode.SystemAudio => PrompterAudioMode.Muted,
            _ => PrompterAudioMode.Microphone
        });
    }

    private void SetAudioMode(PrompterAudioMode mode)
    {
        _audioMode = mode;
        AudioIcon.Text = mode switch
        {
            PrompterAudioMode.SystemAudio => "\uE767",
            PrompterAudioMode.Muted => "\uE74F",
            _ => "\uE720"
        };
        AudioIcon.Foreground = (Brush)FindResource(mode == PrompterAudioMode.Muted ? "IslandSecondary" : "IslandYellow");
        AudioInputChanged?.Invoke(mode);
        if (mode == PrompterAudioMode.Muted)
        {
            foreach (var bar in new[] { Wave1, Wave2, Wave3, Wave4, Wave5, Wave6 }) bar.Height = 3;
        }
    }

    private void CodeButton_Click(object sender, RoutedEventArgs e)
    {
        if (CodeLanguagePopup.IsOpen)
        {
            CodeLanguagePopup.IsOpen = false;
            return;
        }
        CodeLanguageInput.Text = _codeLanguage;
        SetNoActivate(false);
        CodeLanguagePopup.IsOpen = true;
        Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() =>
        {
            Activate();
            CodeLanguageInput.Focus();
            CodeLanguageInput.SelectAll();
        }));
    }

    private void CodeLanguage_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not FrameworkElement { Tag: string language }) return;
        SaveCodeLanguage(language);
    }

    private void CodeLanguageSave_Click(object sender, RoutedEventArgs e) => SaveCodeLanguage(CodeLanguageInput.Text);

    private void CodeLanguageInput_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter) return;
        SaveCodeLanguage(CodeLanguageInput.Text);
        e.Handled = true;
    }

    private void SaveCodeLanguage(string language)
    {
        language = language.Trim();
        if (language.Length == 0) language = "python";
        _codeLanguage = language;
        CodeLanguageText.Text = language;
        CodeLanguagePopup.IsOpen = false;
    }

    private void CodeLanguagePopup_Closed(object? sender, EventArgs e) => SetNoActivate(true);

    private void SetNoActivate(bool noActivate)
    {
        if (_windowHandle == nint.Zero) return;
        var style = NativeMethods.GetWindowLong(_windowHandle, NativeMethods.GwlExStyle) | NativeMethods.WsExToolWindow;
        style = noActivate ? style | NativeMethods.WsExNoActivate : style & ~NativeMethods.WsExNoActivate;
        _ = NativeMethods.SetWindowLong(_windowHandle, NativeMethods.GwlExStyle, style);
    }

    private void ModeButton_Click(object sender, RoutedEventArgs e)
    {
        CodeLanguagePopup.IsOpen = false;
        _isDirectorMode = !_isDirectorMode;
        _session.Kind = _isDirectorMode ? "director" : "formal";
        _session.UpdatedAt = DateTimeOffset.Now;
        _store.ScheduleSave();
        ApplyPrompterMode(refreshContent: true);
        DirectorModeChanged?.Invoke(_isDirectorMode);
    }

    private void ApplyPrompterMode(bool refreshContent)
    {
        AiOnlyTools.Visibility = _isDirectorMode ? Visibility.Collapsed : Visibility.Visible;
        AiKnowledgeButton.Visibility = _isDirectorMode ? Visibility.Collapsed : Visibility.Visible;
        ModeButton.ToolTip = _isDirectorMode
            ? Localized("Switch to AI mode", "切换到 AI 模式")
            : Localized("Switch to Director mode", "切换到导演模式");
        if (refreshContent) RefreshTurns(showLatest: true);
    }

    private void KnowledgeButton_Click(object sender, RoutedEventArgs e)
    {
        if (Application.Current.MainWindow?.DataContext is MainViewModel mainViewModel) mainViewModel.NavigateTo("Knowledge Base");
        Application.Current.MainWindow?.Show();
        Application.Current.MainWindow?.Activate();
    }

    private void ResizeHandle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        _isResizing = true; _resizeStartScreenY = PointToScreen(e.GetPosition(this)).Y; _resizeStartHeight = ActualHeight; Mouse.Capture((IInputElement)sender); e.Handled = true;
    }

    private void ResizeHandle_MouseMove(object sender, MouseEventArgs e)
    {
        if (!_isResizing || e.LeftButton != MouseButtonState.Pressed) return;
        _expandedHeight = Math.Clamp(_resizeStartHeight + PointToScreen(e.GetPosition(this)).Y - _resizeStartScreenY, 180, 520); Height = _expandedHeight;
    }

    private void ResizeHandle_MouseLeftButtonUp(object sender, MouseButtonEventArgs e) { _isResizing = false; Mouse.Capture(null); e.Handled = true; }
    private void CloseButton_Click(object sender, RoutedEventArgs e) => Close();
}

public enum PrompterAudioMode
{
    Microphone,
    SystemAudio,
    Muted
}
