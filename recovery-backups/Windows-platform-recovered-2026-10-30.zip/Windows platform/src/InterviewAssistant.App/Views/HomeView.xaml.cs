using System.Windows.Controls;
namespace InterviewAssistant.Views;
public partial class HomeView : UserControl
{
    private Windows.PrompterWindow? _prompterWindow;
    private ViewModels.HomeViewModel? _subscribedViewModel;

    public HomeView() => InitializeComponent();

    private void HomeView_Loaded(object sender, System.Windows.RoutedEventArgs e)
    {
        if (DataContext is not ViewModels.HomeViewModel viewModel || ReferenceEquals(_subscribedViewModel, viewModel)) return;
        if (_subscribedViewModel is not null) _subscribedViewModel.InterviewStarted -= OpenInterviewPrompter;
        _subscribedViewModel = viewModel;
        viewModel.InterviewStarted += OpenInterviewPrompter;
    }

    private void OpenInterviewPrompter(Models.InterviewSessionModel session)
    {
        _prompterWindow?.Close();
        _prompterWindow = new Windows.PrompterWindow(session);
        _prompterWindow.Closed += (_, _) => _prompterWindow = null;
        _prompterWindow.Show();
    }

    private void PrompterPreviewButton_Click(object sender, System.Windows.RoutedEventArgs e)
    {
        if (_prompterWindow is { IsVisible: true })
        {
            return;
        }

        _prompterWindow = new Windows.PrompterWindow();
        _prompterWindow.Closed += (_, _) => _prompterWindow = null;
        _prompterWindow.Show();
    }
}
