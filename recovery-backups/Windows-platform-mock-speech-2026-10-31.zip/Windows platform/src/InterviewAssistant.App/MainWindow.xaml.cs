using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Runtime.InteropServices;
using InterviewAssistant.Windows;

namespace InterviewAssistant;

public partial class MainWindow : Window
{
    private PrompterWindow? _prompterWindow;

    public MainWindow()
    {
        InitializeComponent();
        if (DataContext is ViewModels.MainViewModel viewModel)
        {
            viewModel.InterviewStarted += OpenInterviewPrompter;
            viewModel.MockInterviewRequested += OpenMockInterview;
        }
    }

    private void OpenMockInterview(Models.MockInterviewLaunchConfig config)
    {
        var window = new Windows.MockInterviewWindow(config) { Owner = this };
        window.Closed += (_, _) =>
        {
            if (DataContext is ViewModels.MainViewModel viewModel) viewModel.RefreshHistory();
        };
        window.Show();
    }

    private void OpenInterviewPrompter(Models.InterviewSessionModel session)
    {
        Dispatcher.BeginInvoke(
            System.Windows.Threading.DispatcherPriority.Loaded,
            new Action(() =>
            {
                _prompterWindow?.Close();
                _prompterWindow = new PrompterWindow(session);
                _prompterWindow.Closed += (_, _) => _prompterWindow = null;
                _prompterWindow.Show();
            }));
    }

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        var source = HwndSource.FromHwnd(new WindowInteropHelper(this).Handle);
        source?.AddHook(WindowMessageHook);
        ApplyRoundedCorners();
    }

    private static nint WindowMessageHook(nint windowHandle, int message, nint wParam, nint lParam, ref bool handled)
    {
        if (message != NativeMethods.WmGetMinMaxInfo || lParam == nint.Zero) return nint.Zero;
        var monitor = NativeMethods.MonitorFromWindow(windowHandle, NativeMethods.MonitorDefaultToNearest);
        var info = new NativeMethods.MonitorInfo { Size = Marshal.SizeOf<NativeMethods.MonitorInfo>() };
        if (monitor == nint.Zero || !NativeMethods.GetMonitorInfo(monitor, ref info)) return nint.Zero;
        var minMax = Marshal.PtrToStructure<NativeMethods.MinMaxInfo>(lParam);
        minMax.MaxPosition.X = Math.Abs(info.WorkArea.Left - info.Monitor.Left);
        minMax.MaxPosition.Y = Math.Abs(info.WorkArea.Top - info.Monitor.Top);
        minMax.MaxSize.X = info.WorkArea.Right - info.WorkArea.Left;
        minMax.MaxSize.Y = info.WorkArea.Bottom - info.WorkArea.Top;
        Marshal.StructureToPtr(minMax, lParam, true);
        handled = true;
        return nint.Zero;
    }

    private void ApplyRoundedCorners()
    {
        try
        {
            var handle = new WindowInteropHelper(this).Handle;
            var preference = NativeMethods.DwmwcpRound;
            _ = NativeMethods.DwmSetWindowAttribute(handle, NativeMethods.DwmwaWindowCornerPreference, ref preference, Marshal.SizeOf<int>());
        }
        catch
        {
            // Older Windows versions do not expose the corner preference attribute.
        }
    }

    private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2)
        {
            ToggleMaximize();
            return;
        }

        DragMove();
    }

    private void MinimizeButton_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void MaximizeButton_Click(object sender, RoutedEventArgs e) => ToggleMaximize();
    private void CloseButton_Click(object sender, RoutedEventArgs e) => Close();

    protected override void OnClosed(EventArgs e)
    {
        _prompterWindow?.Close();
        base.OnClosed(e);
    }

    private void ToggleMaximize() =>
        WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
}
