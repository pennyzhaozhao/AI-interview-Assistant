using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using InterviewAssistant.Models;

namespace InterviewAssistant.Services;

public sealed class AIService
{
    private readonly HttpClient _httpClient = new()
    {
        Timeout = TimeSpan.FromSeconds(120)
    };

    public async Task<string> CompleteAsync(
        AIConfig config,
        string systemPrompt,
        string question,
        int maxTokens = 900,
        CancellationToken cancellationToken = default)
    {
        Validate(config);
        return config.Provider switch
        {
            AIProvider.Claude => await CompleteClaudeAsync(config, systemPrompt, question, maxTokens, cancellationToken),
            AIProvider.Gemini => await CompleteGeminiAsync(config, systemPrompt, question, maxTokens, cancellationToken),
            _ => await CompleteOpenAICompatibleAsync(config, systemPrompt, question, maxTokens, cancellationToken)
        };
    }

    public Task<string> TestConnectionAsync(AIConfig config, CancellationToken cancellationToken = default) =>
        CompleteAsync(config, "Reply briefly and clearly.", "Reply with OK.", 32, cancellationToken);

    private async Task<string> CompleteOpenAICompatibleAsync(
        AIConfig config,
        string systemPrompt,
        string question,
        int maxTokens,
        CancellationToken cancellationToken)
    {
        var baseUrl = NormalizeBaseUrl(config.ApiUrl);
        using var request = new HttpRequestMessage(HttpMethod.Post, $"{baseUrl}/chat/completions");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", string.IsNullOrWhiteSpace(config.ApiKey) ? "ollama" : config.ApiKey);

        var body = new JsonObject
        {
            ["model"] = config.Model,
            ["stream"] = false,
            ["max_tokens"] = maxTokens,
            ["messages"] = new JsonArray
            {
                new JsonObject { ["role"] = "system", ["content"] = systemPrompt },
                new JsonObject { ["role"] = "user", ["content"] = question }
            }
        };
        if (config.Provider == AIProvider.DeepSeek)
        {
            body["thinking"] = new JsonObject { ["type"] = "disabled" };
        }

        request.Content = JsonContent.Create(body);
        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);
        EnsureSuccess(response, responseBody);

        using var document = JsonDocument.Parse(responseBody);
        var text = document.RootElement
            .GetProperty("choices")[0]
            .GetProperty("message")
            .GetProperty("content")
            .GetString();
        return RequireText(text);
    }

    private async Task<string> CompleteClaudeAsync(
        AIConfig config,
        string systemPrompt,
        string question,
        int maxTokens,
        CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, config.ApiUrl);
        request.Headers.Add("x-api-key", config.ApiKey);
        request.Headers.Add("anthropic-version", "2023-06-01");
        request.Content = JsonContent.Create(new
        {
            model = config.Model,
            max_tokens = maxTokens,
            system = systemPrompt,
            messages = new[] { new { role = "user", content = question } }
        });

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);
        EnsureSuccess(response, responseBody);

        using var document = JsonDocument.Parse(responseBody);
        var text = document.RootElement.GetProperty("content")[0].GetProperty("text").GetString();
        return RequireText(text);
    }

    private async Task<string> CompleteGeminiAsync(
        AIConfig config,
        string systemPrompt,
        string question,
        int maxTokens,
        CancellationToken cancellationToken)
    {
        var baseUrl = config.ApiUrl.Trim().TrimEnd('/');
        var url = $"{baseUrl}/models/{Uri.EscapeDataString(config.Model)}:generateContent?key={Uri.EscapeDataString(config.ApiKey)}";
        var body = new
        {
            systemInstruction = new { parts = new[] { new { text = systemPrompt } } },
            contents = new[] { new { role = "user", parts = new[] { new { text = question } } } },
            generationConfig = new { maxOutputTokens = maxTokens }
        };

        using var response = await _httpClient.PostAsJsonAsync(url, body, cancellationToken);
        var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);
        EnsureSuccess(response, responseBody);

        using var document = JsonDocument.Parse(responseBody);
        var text = document.RootElement
            .GetProperty("candidates")[0]
            .GetProperty("content")
            .GetProperty("parts")[0]
            .GetProperty("text")
            .GetString();
        return RequireText(text);
    }

    private static string NormalizeBaseUrl(string value)
    {
        var result = value.Trim().TrimEnd('/');
        foreach (var suffix in new[] { "/chat/completions", "/responses", "/messages" })
        {
            if (result.EndsWith(suffix, StringComparison.OrdinalIgnoreCase))
            {
                result = result[..^suffix.Length];
                break;
            }
        }
        return result;
    }

    private static void Validate(AIConfig config)
    {
        if (!Uri.TryCreate(config.ApiUrl, UriKind.Absolute, out _))
        {
            throw new InvalidOperationException("The API URL is empty or invalid.");
        }
        if (string.IsNullOrWhiteSpace(config.Model))
        {
            throw new InvalidOperationException("Choose an AI model first.");
        }
        if (ProviderCatalog.Get(config.Provider).RequiresApiKey && string.IsNullOrWhiteSpace(config.ApiKey))
        {
            throw new InvalidOperationException("Enter the API key for this provider.");
        }
    }

    private static void EnsureSuccess(HttpResponseMessage response, string responseBody)
    {
        if (!response.IsSuccessStatusCode)
        {
            var detail = responseBody.Length > 800 ? responseBody[..800] : responseBody;
            throw new HttpRequestException($"AI request failed ({(int)response.StatusCode}): {detail}");
        }
    }

    private static string RequireText(string? text)
    {
        var result = text?.Trim() ?? "";
        return result.Length == 0
            ? throw new InvalidOperationException("The AI provider returned an empty response.")
            : result;
    }
}
