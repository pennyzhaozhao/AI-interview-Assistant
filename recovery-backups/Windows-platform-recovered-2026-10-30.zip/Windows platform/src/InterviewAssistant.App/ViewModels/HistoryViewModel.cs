using System.Collections.ObjectModel;
using InterviewAssistant.Infrastructure;
using InterviewAssistant.Models;
using InterviewAssistant.Services;
using System.Windows.Input;

namespace InterviewAssistant.ViewModels;

public sealed class HistoryViewModel : PageViewModel
{
    private InterviewHistoryItem? _selectedSession;
    private string _searchText = "";
    private string _selectedKind = "formal";
    private bool _isSelectionMode;

    public HistoryViewModel() : base("History", "Review formal and mock interview sessions stored on this device.")
    {
        SetKindCommand = new RelayCommand<string>(kind => SelectedKind = kind);
        ToggleSelectionModeCommand = new RelayCommand(() => IsSelectionMode = !IsSelectionMode);
        DeleteSelectedCommand = new RelayCommand(DeleteSelected);
        LocalizationManager.Instance.LanguageChanged += () =>
        {
            OnPropertyChanged(nameof(SelectionButtonText));
            Refresh();
        };
        AppServices.Current.DataStore.DataReset += Refresh;
        Refresh();
    }

    public ObservableCollection<InterviewHistoryItem> Sessions { get; } = [];
    public bool IsEmpty => Sessions.Count == 0;
    public ICommand SetKindCommand { get; }
    public ICommand ToggleSelectionModeCommand { get; }
    public ICommand DeleteSelectedCommand { get; }
    public string SearchText { get => _searchText; set { if (SetProperty(ref _searchText, value)) Refresh(); } }
    public string SelectedKind { get => _selectedKind; set { if (SetProperty(ref _selectedKind, value)) Refresh(); } }
    public bool IsSelectionMode
    {
        get => _isSelectionMode;
        private set
        {
            if (!SetProperty(ref _isSelectionMode, value)) return;
            OnPropertyChanged(nameof(SelectionButtonText));
            if (!value) foreach (var item in Sessions) item.IsBulkSelected = false;
        }
    }
    public string SelectionButtonText => LocalizationManager.Text(IsSelectionMode ? "Cancel" : "Select");

    public InterviewHistoryItem? SelectedSession
    {
        get => _selectedSession;
        set => SetProperty(ref _selectedSession, value);
    }

    public void Refresh()
    {
        var selectedId = SelectedSession?.Id;
        Sessions.Clear();
        foreach (var session in AppServices.Current.DataStore.Data.Sessions
                     .Where(item => item.Kind == SelectedKind)
                     .Where(item => string.IsNullOrWhiteSpace(SearchText) || item.Role.Contains(SearchText, StringComparison.OrdinalIgnoreCase) || item.Title.Contains(SearchText, StringComparison.OrdinalIgnoreCase))
                     .OrderByDescending(item => item.StartedAt))
        {
            Sessions.Add(new InterviewHistoryItem(session));
        }
        SelectedSession = Sessions.FirstOrDefault(item => item.Id == selectedId) ?? Sessions.FirstOrDefault();
        OnPropertyChanged(nameof(IsEmpty));
    }

    private void DeleteSelected()
    {
        var selectedIds = Sessions.Where(item => item.IsBulkSelected).Select(item => item.Id).ToHashSet();
        if (selectedIds.Count == 0) return;
        AppServices.Current.DataStore.Data.Sessions.RemoveAll(item => selectedIds.Contains(item.Id));
        AppServices.Current.DataStore.ScheduleSave();
        IsSelectionMode = false;
        Refresh();
    }
}

public sealed class InterviewHistoryItem(InterviewSessionModel model) : ObservableObject
{
    private bool _isBulkSelected;
    public Guid Id => model.Id;
    public string Role => string.IsNullOrWhiteSpace(model.Role) ? model.Title : model.Role;
    public string StartedAtText => model.StartedAt.LocalDateTime.ToString("g");
    public int QuestionCount => model.Turns.Count;
    public string QuestionCountText => LocalizationManager.Instance.IsChinese
        ? $"{QuestionCount} 个问题"
        : $"{QuestionCount} {(QuestionCount == 1 ? "question" : "questions")}";
    public string Kind => LocalizationManager.Text(model.Kind == "mock" ? "Mock Interview" : "Formal Interview");
    public string Summary => string.IsNullOrWhiteSpace(model.SummaryFeedback) ? LocalizationManager.Text("No summary yet") : model.SummaryFeedback;
    public IReadOnlyList<ConversationTurnModel> Turns => model.Turns;
    public bool IsBulkSelected { get => _isBulkSelected; set => SetProperty(ref _isBulkSelected, value); }
}
