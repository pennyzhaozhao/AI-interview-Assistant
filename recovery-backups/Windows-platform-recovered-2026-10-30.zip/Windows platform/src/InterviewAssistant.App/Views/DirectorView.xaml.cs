using System.Windows.Controls;
namespace InterviewAssistant.Views;
public partial class DirectorView : UserControl
{
    private ViewModels.DirectorViewModel? _subscribedViewModel;
    private Windows.PrompterWindow? _prompterWindow;

    public DirectorView() => InitializeComponent();

    private void DirectorView_Loaded(object sender, System.Windows.RoutedEventArgs e)
    {
        if (DataContext is not ViewModels.DirectorViewModel viewModel || ReferenceEquals(_subscribedViewModel, viewModel)) return;
        if (_subscribedViewModel is not null) _subscribedViewModel.HostBoardRequested -= OpenHostBoard;
        _subscribedViewModel = viewModel;
        viewModel.HostBoardRequested += OpenHostBoard;
    }

    private void OpenHostBoard()
    {
        _prompterWindow?.Close();
        _prompterWindow = new Windows.PrompterWindow();
        _prompterWindow.Closed += (_, _) => _prompterWindow = null;
        _prompterWindow.Show();
    }
}
