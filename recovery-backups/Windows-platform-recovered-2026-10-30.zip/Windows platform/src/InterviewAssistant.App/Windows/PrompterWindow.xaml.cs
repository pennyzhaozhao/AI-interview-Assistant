using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using InterviewAssistant.Models;

namespace InterviewAssistant.Windows;

public partial class PrompterWindow : Window
{
    private nint _windowHandle;

    public PrompterWindow()
    {
        InitializeComponent();
        Loaded += PositionAtTopCenter;
    }

    public PrompterWindow(InterviewSessionModel session) : this()
    {
        PrompterTitle.Text = string.IsNullOrWhiteSpace(session.Role) ? "Interview ready" : session.Role;
        PrompterBody.Text = "Listening is not started yet. Windows audio capture and speech recognition are the next platform milestone.";
    }

    public bool CaptureExclusionApplied { get; private set; }

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        _windowHandle = new WindowInteropHelper(this).Handle;

        var extendedStyle = NativeMethods.GetWindowLong(_windowHandle, NativeMethods.GwlExStyle);
        _ = NativeMethods.SetWindowLong(
            _windowHandle,
            NativeMethods.GwlExStyle,
            extendedStyle | NativeMethods.WsExToolWindow | NativeMethods.WsExNoActivate);

        CaptureExclusionApplied = NativeMethods.SetWindowDisplayAffinity(
            _windowHandle,
            NativeMethods.WdaExcludeFromCapture);
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        if (_windowHandle != nint.Zero)
        {
            _ = NativeMethods.SetWindowDisplayAffinity(_windowHandle, 0);
        }

        base.OnClosing(e);
    }

    private void PositionAtTopCenter(object sender, RoutedEventArgs e)
    {
        var workArea = SystemParameters.WorkArea;
        Left = workArea.Left + Math.Max(0, (workArea.Width - ActualWidth) / 2);
        Top = workArea.Top + 12;
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e) => Close();
}
