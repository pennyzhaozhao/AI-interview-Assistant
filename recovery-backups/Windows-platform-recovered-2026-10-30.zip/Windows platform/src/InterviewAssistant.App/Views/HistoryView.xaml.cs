using System.Windows.Controls;
namespace InterviewAssistant.Views;
public partial class HistoryView : UserControl { public HistoryView() => InitializeComponent(); }
